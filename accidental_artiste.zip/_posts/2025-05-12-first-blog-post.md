
---
title: "First Blog Post"
date: 2025-05-12
categories: [introduction]
---

Welcome to my blog! This is the first post on **accidental_artiste**. Stay tuned for more thoughts and stories.
