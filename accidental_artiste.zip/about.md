
---
layout: single
title: "About Me"
permalink: /about/
author_profile: true
---

Hi, I’m the **accidental_artiste** – a traveler through thoughts and snapshots.  
This site is a reflection of moments I've captured and musings I've written.  
