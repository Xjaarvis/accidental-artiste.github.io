
---
layout: home
author_profile: true
title: "Welcome to accidental_artiste"
excerpt: "Thoughts and photos from an accidental artiste."
header:
  overlay_image: /assets/images/gallery/sample.jpg
  overlay_filter: 0.3
---

Welcome to **accidental_artiste** — a personal corner of the web where words meet visuals. Dive into blog posts and explore my photo stories.
