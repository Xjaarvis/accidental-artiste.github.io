
---
layout: single
title: "Photo Gallery"
permalink: /gallery/
author_profile: true
gallery:
  - url: /assets/images/gallery/sample.jpg
    image_path: /assets/images/gallery/sample.jpg
    title: "Sample Photo"
    alt: "Sample photo description"
---

Welcome to the gallery! Here are a few glimpses of my world.
